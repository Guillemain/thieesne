%--------------------------------------------------------------------------
% ENSEEIHT - 2SN MM - Traitement des donnees audio-visuelles
% TP12 - Realite diminuee
% fonction priorites
%--------------------------------------------------------------------------

function [P,C] = priorites(u,D,C,delta_D,delta_D_barre,t)

% Coordonnees (i,j) des points de delta_D_barre :
% A completer

% Tangente normalisee au contour de D :
% A completer

% Gradient de u :
% A completer

% Calcul de P et C en chaque point p de D :
% A completer

		% Calcul des bornes du voisinage de p :
		% A completer

		% Calcul de la confiance C en p :
		% A completer

		% Recherche du point de delta_D_barre le plus proche de p (utiliser dsearchn) :
		% A completer

		% Calcul de la priorite P en p :
		% A completer
